# BFX HUNTER — Automated Signal Bot (Daily + Scalp)

## What this is
A small backend (`server.js`) that:
1. Polls the live XAUUSD price every 15s (same free source your site already uses: gold-api.com).
2. Runs two strategies automatically:
   - **Daily**: EMA(9)/EMA(21) crossover, wider stop/target, cooldown of 6h between signals.
   - **Scalp**: RSI(14) + Bollinger Bands(20,2) extremes, tighter stop/target, cooldown of 15m.
3. **Paper-trades** every signal it opens — it tracks the live price against the signal's SL/TP and
   records a win or loss automatically. No broker order is ever sent.
4. Exposes a small REST API that `BFX_HUNTER_live.html` polls to show:
   - Two "Bot Signals" cards (Daily / Scalp) with live entry/SL/target.
   - A live track record table + stats (win rate, avg R:R, net pips).

## Running it
```bash
cd bfx-bot
npm install
npm start
```
The API listens on `http://localhost:3001` by default (override with `PORT=xxxx npm start`).
Open `BFX_HUNTER_live.html` in a browser (or serve it from any static host) — it will start polling
the bot automatically. If the bot isn't reachable, the page quietly falls back to the original demo
content, so the site never breaks.

## Deploying so it runs 24/7
This needs a small always-on server (a laptop left open on `npm start` also works, but a proper host
is more reliable):
- **Cheapest / easiest**: Railway, Render, or Fly.io free/hobby tier — push this folder, set the start
  command to `npm start`, done.
- **VPS**: any $5/mo box (DigitalOcean, Hetzner, Contabo). Install Node 18+, `npm install`, then run it
  under `pm2` or a systemd service so it restarts on crash/reboot.

Once deployed, edit the `BOT_API` constant near the top of the `<script>` block in
`BFX_HUNTER_live.html` to point at your deployed URL (e.g. `https://your-bot.onrender.com`) instead of
`http://localhost:3001`.

## Connecting a real broker later (real money execution)
Right now `strategies.checkExit()` and the open/close logic in `server.js` only simulate fills against
the live price feed. To place *real* orders you would:
1. Pick a platform with an API: MetaApi.cloud (wraps MT4/MT5), a crypto exchange's REST API, or a
   broker's native REST API (e.g. OANDA).
2. Get an account (start with a **demo** account) and API credentials.
3. Replace the `tryOpenTrades()` / `tryCloseTrades()` bodies in `server.js` with real calls to that
   broker's "place order" / "get position" endpoints instead of the in-memory paper-trade logic.
4. Never commit API keys to source — load them from environment variables.

This is a meaningfully bigger step (money is really at risk), so it's worth testing thoroughly on a
demo account first, and adding safeguards: max daily loss limit, position-size caps, a manual kill
switch, and logging every order.

## Files
- `server.js` — Express API + price polling loop.
- `strategies.js` — indicator math (EMA/RSI/Bollinger) + signal generation + exit-checking.
- `storage.js` — persists bot state to `data.json` so it survives restarts.
- `BFX_HUNTER_live.html` — your site, updated to read from the bot's API.
