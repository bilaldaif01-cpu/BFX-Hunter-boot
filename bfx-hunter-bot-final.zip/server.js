const express = require('express');
// Node 18+ ships a global fetch(), so no extra HTTP-client dependency is needed.
const strategies = require('./strategies');
const storage = require('./storage');

const PORT = process.env.PORT || 3001;
const POLL_MS = 15 * 1000;          // how often we fetch the live price
const DAILY_COOLDOWN_MS = 6 * 60 * 60 * 1000;  // 6h between new daily signals
const SCALP_COOLDOWN_MS = 15 * 60 * 1000;      // 15m between new scalp signals

const state = storage.load();

const app = express();
// Minimal manual CORS so the website (on a different origin) can call this API,
// without needing the extra 'cors' package.
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});
app.use(express.json());

// ---------- price polling ----------
async function fetchLivePrice() {
  const res = await fetch('https://api.gold-api.com/price/XAU', { headers: { 'cache-control': 'no-store' } });
  if (!res.ok) throw new Error('bad response from gold-api');
  const data = await res.json();
  const price = Number(data.price);
  if (!Number.isFinite(price)) throw new Error('bad price payload');
  return price;
}

function pushPrice(price) {
  state.priceHistory.push({ t: Date.now(), price });
  if (state.priceHistory.length > 2000) state.priceHistory.shift();
}

// ---------- trade lifecycle ----------
function tryOpenTrades() {
  if (!state.openTrades.daily) {
    const sig = strategies.evaluateDaily(state.priceHistory, state.cooldowns.daily);
    if (sig) state.openTrades.daily = sig;
  }
  if (!state.openTrades.scalp) {
    const sig = strategies.evaluateScalp(state.priceHistory, state.cooldowns.scalp);
    if (sig) state.openTrades.scalp = sig;
  }
}

function tryCloseTrades(currentPrice) {
  for (const mode of ['daily', 'scalp']) {
    const trade = state.openTrades[mode];
    if (!trade) continue;
    const exit = strategies.checkExit(trade, currentPrice);
    if (!exit) continue;

    const pipDivisor = mode === 'daily' ? trade.entry * 0.0001 : trade.entry * 0.0001; // rough "pip" unit for gold
    const pips = Math.round(Math.abs(exit.exitPrice - trade.entry) / pipDivisor) * (exit.result === 'win' ? 1 : -1);

    state.trackRecord.push({
      date: new Date().toISOString().slice(0, 10),
      mode,
      dir: trade.dir,
      entry: trade.entry.toFixed(2),
      sl: trade.sl.toFixed(2),
      tp: trade.tp.toFixed(2),
      exit: exit.exitPrice.toFixed(2),
      result: exit.result,
      pips,
      rr: trade.rr,
      openedAt: trade.openedAt,
      closedAt: Date.now()
    });

    state.openTrades[mode] = null;
    state.cooldowns[mode] = Date.now() + (mode === 'daily' ? DAILY_COOLDOWN_MS : SCALP_COOLDOWN_MS);
  }
}

async function tick() {
  try {
    const price = await fetchLivePrice();
    pushPrice(price);
    tryCloseTrades(price);
    tryOpenTrades();
    storage.save(state);
  } catch (err) {
    console.error('[bot] tick error:', err.message);
  }
}

setInterval(tick, POLL_MS);
tick(); // fire immediately on boot

// ---------- API ----------
app.get('/api/health', (_req, res) => {
  res.json({ ok: true, historyPoints: state.priceHistory.length });
});

app.get('/api/price', (_req, res) => {
  const last = state.priceHistory[state.priceHistory.length - 1];
  res.json(last ? { price: last.price, at: last.t } : null);
});

app.get('/api/signals/latest', (_req, res) => {
  res.json({
    daily: state.openTrades.daily || lastClosed('daily'),
    scalp: state.openTrades.scalp || lastClosed('scalp')
  });
});

function lastClosed(mode) {
  const list = state.trackRecord.filter(t => t.mode === mode);
  return list.length ? { ...list[list.length - 1], status: 'closed' } : null;
}

app.get('/api/signals/track-record', (req, res) => {
  const mode = req.query.mode; // 'daily' | 'scalp' | undefined (=both)
  const list = mode ? state.trackRecord.filter(t => t.mode === mode) : state.trackRecord;
  const wins = list.filter(t => t.result === 'win').length;
  const pips = list.reduce((a, t) => a + Number(t.pips), 0);
  const avgRR = list.length ? (list.reduce((a, t) => a + Number(t.rr), 0) / list.length).toFixed(2) : '—';
  res.json({
    trades: list.slice(-100).reverse(),
    stats: {
      count: list.length,
      winRate: list.length ? Math.round((wins / list.length) * 100) : 0,
      avgRR,
      netPips: pips
    }
  });
});

app.listen(PORT, () => {
  console.log(`BFX HUNTER bot API listening on :${PORT}`);
});
