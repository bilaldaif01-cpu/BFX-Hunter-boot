/**
 * Indicator + signal-generation logic for the BFX HUNTER bot.
 * Everything here is PAPER TRADING: it decides "would a trade have been
 * opened here, and did it hit TP or SL" purely from the live price feed.
 * It never talks to a broker. Swap `strategies.executeOrder()` for a real
 * broker call later (see README) once you have an account + API keys.
 */

function ema(values, period) {
  if (values.length === 0) return null;
  const k = 2 / (period + 1);
  let emaVal = values[0];
  for (let i = 1; i < values.length; i++) {
    emaVal = values[i] * k + emaVal * (1 - k);
  }
  return emaVal;
}

function emaSeries(values, period) {
  const k = 2 / (period + 1);
  const out = [values[0]];
  for (let i = 1; i < values.length; i++) {
    out.push(values[i] * k + out[i - 1] * (1 - k));
  }
  return out;
}

function rsi(values, period = 14) {
  if (values.length < period + 1) return null;
  let gains = 0, losses = 0;
  for (let i = values.length - period; i < values.length; i++) {
    const diff = values[i] - values[i - 1];
    if (diff >= 0) gains += diff; else losses -= diff;
  }
  const avgGain = gains / period;
  const avgLoss = losses / period;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

function bollinger(values, period = 20, mult = 2) {
  if (values.length < period) return null;
  const slice = values.slice(values.length - period);
  const mean = slice.reduce((a, b) => a + b, 0) / period;
  const variance = slice.reduce((a, b) => a + (b - mean) ** 2, 0) / period;
  const sd = Math.sqrt(variance);
  return { mid: mean, upper: mean + mult * sd, lower: mean - mult * sd };
}

/**
 * Daily strategy: EMA(9)/EMA(21) crossover on the full price history.
 * Wider stop/targets, meant to fire a handful of times per day at most.
 */
function evaluateDaily(history, cooldownUntil) {
  const prices = history.map(h => h.price);
  if (prices.length < 30) return null;
  if (Date.now() < cooldownUntil) return null;

  const fastSeries = emaSeries(prices, 9);
  const slowSeries = emaSeries(prices, 21);
  const n = prices.length;

  const fastPrev = fastSeries[n - 2];
  const slowPrev = slowSeries[n - 2];
  const fastNow = fastSeries[n - 1];
  const slowNow = slowSeries[n - 1];
  const price = prices[n - 1];

  const crossedUp = fastPrev <= slowPrev && fastNow > slowNow;
  const crossedDown = fastPrev >= slowPrev && fastNow < slowNow;

  if (!crossedUp && !crossedDown) return null;

  const dir = crossedUp ? 'BUY' : 'SELL';
  const riskPips = Math.max(price * 0.006, 3); // ~0.6% risk distance, floor for very low-priced instruments
  const rr = 2.4;

  return {
    mode: 'daily',
    dir,
    entry: price,
    sl: dir === 'BUY' ? price - riskPips : price + riskPips,
    tp: dir === 'BUY' ? price + riskPips * rr : price - riskPips * rr,
    rr,
    openedAt: Date.now()
  };
}

/**
 * Scalp strategy: RSI extremes + Bollinger Band touch on a short lookback.
 * Tighter stop/targets, can fire more often (own shorter cooldown).
 */
function evaluateScalp(history, cooldownUntil) {
  const prices = history.map(h => h.price);
  if (prices.length < 25) return null;
  if (Date.now() < cooldownUntil) return null;

  const lookback = prices.slice(-40);
  const r = rsi(lookback, 14);
  const bb = bollinger(lookback, 20, 2);
  if (r === null || bb === null) return null;

  const price = lookback[lookback.length - 1];
  let dir = null;
  if (r < 32 && price <= bb.lower) dir = 'BUY';
  if (r > 68 && price >= bb.upper) dir = 'SELL';
  if (!dir) return null;

  const riskPips = Math.max(price * 0.0018, 1.5);
  const rr = 1.6;

  return {
    mode: 'scalp',
    dir,
    entry: price,
    sl: dir === 'BUY' ? price - riskPips : price + riskPips,
    tp: dir === 'BUY' ? price + riskPips * rr : price - riskPips * rr,
    rr,
    openedAt: Date.now()
  };
}

/**
 * Given an open paper trade and the current price, decide whether it
 * should close (TP or SL hit) and with what result.
 */
function checkExit(trade, currentPrice) {
  if (trade.dir === 'BUY') {
    if (currentPrice >= trade.tp) return { result: 'win', exitPrice: trade.tp };
    if (currentPrice <= trade.sl) return { result: 'loss', exitPrice: trade.sl };
  } else {
    if (currentPrice <= trade.tp) return { result: 'win', exitPrice: trade.tp };
    if (currentPrice >= trade.sl) return { result: 'loss', exitPrice: trade.sl };
  }
  return null;
}

module.exports = { ema, emaSeries, rsi, bollinger, evaluateDaily, evaluateScalp, checkExit };
