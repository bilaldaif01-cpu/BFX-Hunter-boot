const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, 'data.json');

function load() {
  try {
    const raw = fs.readFileSync(FILE, 'utf8');
    return JSON.parse(raw);
  } catch (e) {
    return {
      priceHistory: [],
      openTrades: { daily: null, scalp: null },
      cooldowns: { daily: 0, scalp: 0 },
      trackRecord: []
    };
  }
}

function save(state) {
  // Keep the file small: cap history and track record length.
  const trimmed = {
    ...state,
    priceHistory: state.priceHistory.slice(-2000),
    trackRecord: state.trackRecord.slice(-500)
  };
  fs.writeFileSync(FILE, JSON.stringify(trimmed), 'utf8');
}

module.exports = { load, save };
